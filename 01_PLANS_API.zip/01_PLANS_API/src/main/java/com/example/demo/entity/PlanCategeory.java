package com.example.demo.entity;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import lombok.Data;


@Entity
@Data
@Table
public class PlanCategeory {

	@Id
	@GeneratedValue
	private Integer categeoryId;
	
	private String categeoryname;
	
	private String activeSw;
	
	private String createdBy;
	
	private String updatedBy;
	
	@Column(updatable=false)
	@CreationTimestamp
	private LocalDate createDate;
	
	@Column(insertable=false)
	@UpdateTimestamp
	private LocalDate updateDate;

	public Integer getCategeoryId() {
		return categeoryId;
	}

	public void setCategeoryId(Integer categeoryId) {
		this.categeoryId = categeoryId;
	}

	public String getCategeoryname() {
		return categeoryname;
	}

	public void setCategeoryname(String categeoryname) {
		this.categeoryname = categeoryname;
	}

	public String getActiveSw() {
		return activeSw;
	}

	public void setActiveSw(String activeSw) {
		this.activeSw = activeSw;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public LocalDate getCreateDate() {
		return createDate;
	}

	public void setCreateDate(LocalDate createDate) {
		this.createDate = createDate;
	}

	public LocalDate getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(LocalDate updateDate) {
		this.updateDate = updateDate;
	}
	
	
	
}
