package com.example.demo.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Plan;
import com.example.demo.entity.PlanCategeory;
import com.example.demo.repository.PlanCategeoryRepo;
import com.example.demo.repository.PlanRepo;

@Service
public class PlanServiceImpl implements PlanService {

	@Autowired
	private PlanCategeoryRepo planCategeoryRepo;

	@Autowired
	private PlanRepo planRepo;

	@Override
	public Map<Integer, String> getPlanCategeories() {
		List<PlanCategeory> catergeories = planCategeoryRepo.findAll();

		Map<Integer, String> categeorymap = new HashMap<>();

		catergeories.forEach(category -> {
			categeorymap.put(category.getCategeoryId(), category.getCategeoryname());
		});
		return categeorymap;

	}

	@Override
	public boolean savePlan(Plan plan) {
		Plan p = planRepo.save(plan);
//		if (p.getPlanId() != null) {
//			return true;
//		} else {
//			return false;
//		}
		
//		return p.getPlanId()!=null ?true:false;
		
		return p.getPlanId()!=null;
	}

	@Override
	public boolean updatePlan(Plan plan) {
		Plan p = planRepo.save(plan);
		return p.getPlanId()!=null;
	}

	@Override
	public List<Plan> getAllPlans() {
		return planRepo.findAll();
	}

	@Override
	public Plan getPlanById(Integer planId) {
		// TODO Auto-generated method stub
		Optional<Plan> findById = planRepo.findById(planId);
		if(findById.isPresent()) {
			return findById.get();
		}
		return null;
	}

	@Override
	public boolean deletePlan(Integer planId) {
		boolean status=false;
		try{
			planRepo.deleteById(planId);
			status=true;
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return status;
	}

	@Override
	public boolean planStatusChange(Integer planId, String status) {
		Optional<Plan> findById = planRepo.findById(planId);
			if(findById.isPresent()) {
			Plan plan=findById.get();
			plan.setActiveSw(status);
			planRepo.save(plan);
			return true;
		}
		return false;
	}

}
