package com.example.demo.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Plan;
import com.example.demo.service.PlanService;

@RestController
public class PlanRestController {

	@Autowired
	private PlanService planService;

	@GetMapping("/categeories")
	public ResponseEntity<Map<Integer, String>> getPlanCategeories() {
		Map<Integer, String> categeories = planService.getPlanCategeories();
		return new ResponseEntity<>(categeories, HttpStatus.OK);
	};

	@PostMapping("/save")
	public ResponseEntity<String> savePlan(@RequestBody Plan plan) {
		String responseMsg = "";

		boolean isSaved = planService.savePlan(plan);
		if (isSaved) {
			responseMsg = "Plan saved";
		} else {
			responseMsg = "Plan not saved";
		}
		return new ResponseEntity<>(responseMsg, HttpStatus.CREATED);

	};

	@PutMapping("/updateplans")
	public ResponseEntity<String> updatePlan(Plan plan) {
		String responseMsg = "";

		boolean isUpdated = planService.updatePlan(plan);
		if (isUpdated) {
			responseMsg = "Plan Updated";
		} else {
			responseMsg = "Plan not Updated";
		}
		return new ResponseEntity<>(responseMsg, HttpStatus.OK);

	};

	@GetMapping("/plans")
	public ResponseEntity<List<Plan>> getAllPlans() {
		List<Plan> plans = planService.getAllPlans();

		return new ResponseEntity<>(plans, HttpStatus.OK);

	};

	public ResponseEntity<Plan> getPlanById(Integer planId) {
		return null;

	};

	@GetMapping("/plan/{planId}")
	public ResponseEntity<Plan> editPlan(@PathVariable Integer planId) {
		Plan plan = planService.getPlanById(planId);
		return new ResponseEntity<>(plan, HttpStatus.OK);

	};

	@DeleteMapping("/plan/{planId}")
	public ResponseEntity<String> deletePlan(@PathVariable Integer planId) {
		String responseMsg = "";

		boolean isDeleted = planService.deletePlan(planId);
		if (isDeleted) {
			responseMsg = "Plan deleted";
		} else {
			responseMsg = "Plan not deleted";
		}
		return new ResponseEntity<>(responseMsg, HttpStatus.OK);

	};

	@PutMapping("/planstatuschanged/{planId}/{status}")
	public ResponseEntity<String> planStatusChange(@PathVariable Integer planId, @PathVariable String status) {

		String responseMsg = "";

		boolean isStatusChanged = planService.planStatusChange(planId, status);
		if (isStatusChanged) {
			responseMsg = "Plan status Changed";
		} else {
			responseMsg = "Plan status not Changed";
		}
		return new ResponseEntity<>(responseMsg, HttpStatus.OK);

	};

}
