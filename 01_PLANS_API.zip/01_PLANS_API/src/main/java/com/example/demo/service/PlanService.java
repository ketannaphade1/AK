package com.example.demo.service;

import java.util.List;
import java.util.Map;

import com.example.demo.entity.Plan;

public interface PlanService {
	
	public Map<Integer,String> getPlanCategeories();
	
	public boolean savePlan(Plan plan);
	
	public boolean updatePlan(Plan plan);
	
	public List<Plan> getAllPlans();
	
	public Plan getPlanById(Integer planId);
	
	public boolean deletePlan(Integer planId);
	
	public boolean planStatusChange(Integer planId,String status);
	
	
	
	
	
	
	
	
	

}
