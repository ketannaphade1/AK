package com.example.service;

import java.util.List;

import javax.servlet.http.HttpServletResponse;

import com.example.entity.SearchRequest;
import com.example.entity.SearchResponse;

public interface ReportService {
	
	public List<String> getUniquePlanNames();
	
	public List<String> getUniquePlanStatus();

	public List<SearchResponse> search(SearchRequest search);
	
	public void generateExcel(HttpServletResponse response);
	
	public void generatePdf(HttpServletResponse response) throws Exception;
	

	


}
