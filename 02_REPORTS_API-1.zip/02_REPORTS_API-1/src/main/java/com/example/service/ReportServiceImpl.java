package com.example.service;

import java.io.FileOutputStream;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.stereotype.Service;

import com.example.entity.EligibilityDetails;
import com.example.entity.SearchRequest;
import com.example.entity.SearchResponse;
import com.example.repository.EligibilityDetailsRepo;
import com.lowagie.text.Document;
import com.lowagie.text.Image;
import com.lowagie.text.PageSize;
import com.lowagie.text.pdf.PdfWriter;

@Service
public class ReportServiceImpl implements ReportService {

	@Autowired
	private EligibilityDetailsRepo eligrepo;

	@Override
	public List<String> getUniquePlanNames() {

		return eligrepo.getUniquePlanName();
	}

	@Override
	public List<String> getUniquePlanStatus() {

		return eligrepo.getUniquePlanStatus();
	}

	@Override
	public List<SearchResponse> search(SearchRequest request) {

		EligibilityDetails queryBuilder = new EligibilityDetails();

		String planName = request.getPlanName();

		String planStatus = request.getPlanStatus();

		LocalDate planStartDate = request.getPlanStartDate();

		LocalDate planEndDate = request.getPlanEndDate();

		if (planName != null && !planName.equals("")) {
			queryBuilder.setPlanName(planName);
		}
		if (planStatus != null && !planStatus.equals("")) {
			queryBuilder.setPlanStatus(planStatus);
		}
		if (planStartDate != null) {
			queryBuilder.setPlanStartDate(planStartDate);
		}
		if (planEndDate != null) {
			queryBuilder.setPlanEndDate(planEndDate);
		}

		Example<EligibilityDetails> example = Example.of(queryBuilder);
		;

		List<SearchResponse> response = new ArrayList<>();

		List<EligibilityDetails> entities = eligrepo.findAll(example);

		for (EligibilityDetails entity : entities) {
			SearchResponse sr = new SearchResponse();
			BeanUtils.copyProperties(entity, sr);
			response.add(sr);
		}

		return response;
	}

	@Override
	public void generateExcel(HttpServletResponse response) {
		List<EligibilityDetails> entities = eligrepo.findAll();

		HSSFWorkbook workbook = new HSSFWorkbook();
		HSSFSheet sheet = workbook.createSheet();
		HSSFRow headerRow = sheet.createRow(0);

		headerRow.createCell(0).setCellValue("Name");
		headerRow.createCell(1).setCellValue("Mobile");
		headerRow.createCell(2).setCellValue("Gender");
		headerRow.createCell(3).setCellValue("SSN");

		entities.forEach(entity -> {
			int i = 1;
			HSSFRow dataRow = sheet.createRow(i);
			dataRow.createCell(0).setCellValue(entity.getName());
			dataRow.createCell(0).setCellValue(entity.getMobile());
			dataRow.createCell(0).setCellValue(entity.getGender());
			dataRow.createCell(0).setCellValue(entity.getSsn());

			i++;
		});

	}

	@Override
	public void generatePdf(HttpServletResponse response) throws Exception {
		List<EligibilityDetails> entities = eligrepo.findAll();

		Document document = new Document(PageSize.A4);
		PdfWriter.getInstance(document, response.getOutputStream());
		document.open();

	};

}
